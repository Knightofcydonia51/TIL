import sys
sys.stdin=open("min_max_input.txt")

T=int(input())
for i in range(T):
    N=int(input())
    data=[int(x) for x in input().split()]
    for k in range(len(data)-1,0,-1):
        for j in range(k):
            if data[j]>data[j+1]:
                data[j+1], data[j]=data[j], data[j+1]
    print('#{} {}'.format(i+1,data[-1]-data[0]))