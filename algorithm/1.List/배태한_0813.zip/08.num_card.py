import sys
sys.stdin=open("num_card_input.txt")
T=int(input())
for i in range(T):
    N=int(input())
    data=input()
    counts=[0]*10
    for k in data:
        counts[int(k)]+=1
    for idx, j in enumerate(counts):
        if j==max(counts):
            maxest=idx
    print('#{} {} {}'.format(i+1,maxest,max(counts)))