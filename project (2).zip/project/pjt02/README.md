# 02 - 파이썬을 활용한 데이터 수집 II 



## 01. 사용한 API

- 네이버 영화검색 API https://developers.naver.com/docs/search/movie/
- 한국 영화진흥위원회 API



## 02. 파일 목록

### - movie.csv

![](movie.PNG)
- fieldnames=[영화 대표코드,영화명(국문),영화명(영문),영화명(원문),관람등급,개봉연도,상영시간,장르,감독]
- 영화 진흥위원회에서 제공하는 api를 통해 수집된 영화의 상세정보를 담고 있는 csv 파일.



### - movie_naver.csv
![](movie_naver.PNG)

- fieldnames = ['영진위 영화 대표코드', '하이퍼텍스 link', '영화 썸네일 이미지의 URL', '유저 평점']
- 네이버 영화정보 link, 영화 이미지 url, 유저 평점 등의 정보를 담고 있는 csv 파일.
- 
