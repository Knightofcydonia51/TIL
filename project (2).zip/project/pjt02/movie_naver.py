from decouple import config
from pprint import pprint
import requests
import csv

client_id = config('NAVER_CLIENT_ID')
client_secret = config('NAVER_CLIENT_SECRET')
headers = {
        'X-Naver-Client-Id': client_id, 
        'X-Naver-Client-Secret': client_secret
    }

with open('movie_naver.csv', 'w', newline='', encoding='utf-8') as f:
    fieldnames = ['영진위 영화 대표코드', '하이퍼텍스 link', '영화 썸네일 이미지의 URL', '유저 평점']
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    with open('movie.csv', newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)

        for row in reader:
            movie=row['영화명(국문)'].replace(' ','')
            url=f'https://openapi.naver.com/v1/search/movie.json?query={movie}'
            response = requests.get(url, headers=headers).json()
            dic={'영진위 영화 대표코드':row['영화 대표코드']}

            for i in range(0,len(response.get('items'))):
                movie_link=response.get('items')[i]['link']
                movie_image=response.get('items')[i]['image']
                movie_userRating=response.get('items')[i]['userRating']
                dic.update({'하이퍼텍스 link':movie_link,'영화 썸네일 이미지의 URL':movie_image,'유저 평점':movie_userRating})
                writer.writerow(dic)
                break
