import requests
import csv


with open('movie_naver.csv', newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        jpg=row['영화 썸네일 이미지의 URL']
        code=row['영진위 영화 대표코드']
        with open(f'images/{code}.jpg', 'wb') as f:
            image=requests.get(jpg, stream=True).content
            f.write(image)