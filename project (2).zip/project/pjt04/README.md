# pjt04 - HTML/CSS/Bootstrap을 활용한 웹 사이트 구성

- HTML과 CSS를 연결해 홈페이지를 원하는 대로 조작.
- grid,modal 속성을 활용한 홈페이지 레이아웃 구성.

