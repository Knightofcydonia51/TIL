import csv
import requests
import datetime
from pprint import pprint
from decouple import config

key = config('API_KEY')

people_list = []

with open('moive.csv', newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)

    # 한줄씩 읽는다.
    # for row in reader:
    
    for row in reader:
        peopleNm_= row['peopleNm']
        Base_URL = f'http://www.kobis.or.kr/kobisopenapi/webservice/rest/people/searchPeopleList.json?key={key}&peopleNm={peopleNm_}'
        response = requests.get(Base_URL)
        detail_info = response.json()
        people_list.append(detail_info.get('peopleListResult').get('peopleList')[0])
        print(people_list)

with open('director.csv', 'w', newline='', encoding='utf-8') as f:

    fieldnames = ['peopleCd', 'peopleNm', 'repRoleNm','filmoNames']
    writer = csv.DictWriter(f, fieldnames=fieldnames)

    writer.writeheader()

    dic = {}
    for i in people_list:
        peopleCd1 = i.get('peopleCd')
        peopleNm1 = i.get('peopleNm')
        repRoleNm1 = i.get('repRoleNm')
        filmoNames1 = i.get('filmoNames')
        
        dic = {'peopleCd':peopleCd1,'peopleNm':peopleNm1,'repRoleNm':repRoleNm1,'filmoNames':filmoNames1}
        writer.writerow(dic)
        del dic