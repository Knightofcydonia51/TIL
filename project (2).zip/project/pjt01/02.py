from decouple import config
import requests
import csv
import json
import datetime



key = config('API_KEY')
Top10_list = []

with open('boxoffice.csv', newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)

    # 한줄씩 읽는다.
    # for row in reader:
    
    for row in reader:
        movieCd_= row['movieCd']
        Base_URL = f'http://www.kobis.or.kr/kobisopenapi/webservice/rest/movie/searchMovieInfo.json?key={key}&movieCd={movieCd_}'
        response = requests.get(Base_URL)
        detail_info = response.json()
        Top10_list.append(detail_info.get('movieInfoResult').get('movieInfo'))


with open('moive.csv', 'w', newline='', encoding='utf-8') as f:

    fieldnames = ['movieCd', 'movieNm', 'movieNmEn','movieNmOg','watchGradeNm','showTm','openDt','genreNm','peopleNm']
    writer = csv.DictWriter(f, fieldnames=fieldnames)

    writer.writeheader()

    dic = {}
    for i in Top10_list:
        movieCd1 = i.get('movieCd')
        movieNm1 = i.get('movieNm')
        movieNmEn1 = i.get('movieNmEn')
        movieNmOg1 = i.get('movieNmOg')
        if i.get('audits'):
            watchGradeNm1 = i.get('audits')[0].get('watchGradeNm')
        else:
            watchGradeNm1 = ''
        showTm1 = i.get('showTm')
        openDt1 = i.get('openDt')
        if i.get('genres'):
            genreNm1 = i.get('genres')[0].get('genreNm')
        else:
            genreNm1 = ''
        if i.get('directors'):
            peopleNm1 = i.get('directors')[0].get('peopleNm')
        else:
            peopleNm1 = ''
        
        dic = {'movieCd':movieCd1,'movieNm':movieNm1,'movieNmEn':movieNmEn1,'movieNmOg':movieNmOg1,'watchGradeNm':watchGradeNm1,'showTm':showTm1,'openDt':openDt1,'genreNm':genreNm1,'peopleNm':peopleNm1}
        writer.writerow(dic)
        del dic



