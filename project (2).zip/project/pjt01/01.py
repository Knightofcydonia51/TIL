from decouple import config
import requests
import csv
import json
import datetime



key = config('API_KEY')
print(key)

html = 'http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchWeeklyBoxOfficeList.json?key={}&targetDt=20190713'.format(key)
response=requests.get(url=html)
info=response.json()

# keylist=[]
# keylist.append(list(info.get('boxOfficeResult').get('weeklyBoxOfficeList')[0].keys())[4])
# keylist.append(list(info.get('boxOfficeResult').get('weeklyBoxOfficeList')[0].keys())[5])
# keylist.append(list(info.get('boxOfficeResult').get('weeklyBoxOfficeList')[0].keys())[15])
# #movieCd movieNm audiAcc
 
# print(info.get('boxOfficeResult').get('weeklyBoxOfficeList')[0].get('movieCd'))
# print(info.get('boxOfficeResult').get('weeklyBoxOfficeList')[0].get('movieNm'))
# print(info.get('boxOfficeResult').get('weeklyBoxOfficeList')[0].get('audiAcc'))


with open ('boxoffice.csv', 'w', newline='', encoding='utf-8') as f:
#     #1. 저장할 데이터들의 필드 이름을 미리 지정한다.
   fieldnames = ['movieCd', 'movieNm', 'audiAcc']
   writer = csv.DictWriter(f, fieldnames=fieldnames)
#     #2 필드 이름을 csv 파일 최상단에 작성한다.
   writer.writeheader()
   moviechart = []

   d = datetime.date(2019, 7, 13)
# 전체적 for 문을 돌려 50주 간격 반복
   for i in range(50):
       date = d.strftime('%Y%m%d')
       url_copy = f'http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchWeeklyBoxOfficeList.json?key={key}&targetDt={date}&weekGb=0'
       response = requests.get(url=url_copy)
       info = response.json()

       d = d + datetime.timedelta(weeks=-1)
   #     #3. dictionary를 순회하며(돈다!) key에 해당하는 value를 한줄씩 작성한다.
       for dict_new in info.get('boxOfficeResult').get('weeklyBoxOfficeList'):
           cnt = 0
           diccts = {}
           for k,v in dict_new.items():
               if k == 'movieCd' and (v in moviechart):
                   cnt = 1
                   break
               else:
                   moviechart.append(v)
               if k == 'movieCd' or k == 'movieNm' or k =='audiAcc':
                       diccts.update([[k,v]])

           if cnt == 1:
               continue

           writer.writerow(diccts)
           del diccts






# print(info.get('boxOfficeResult').get('weeklyBoxOfficeList')[0].get(f'{keylist[0]}'))

# with open('boxoffice.csv', 'w', newline='', encoding='utf-8') as f:
#     #1. 저장할 데이터들의 필드 이름을 미리 지정한다.
#     fieldnames = ['movieCd', 'movieNm', 'audiAcc']
#     writer = csv.DictWriter(f, fieldnames=fieldnames)

#     #2. 필드 이름을 csv 파일 최상단에 작성한다.
#     writer.writeheader()
#     movielist=[]
    
#     for num in weeklist:
#         html = 'http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchWeeklyBoxOfficeList.json?key={}&targetDt={}'.format(key, num)
#         response=requests.get(url=html)
#         info=response.json()
#         cnt=0
#         dicts={}

#         for keys in keylist:
#             value = info.get('boxOfficeResult').get('weeklyBoxOfficeList')[0].get(f'{keys}') # value
#             if keys == 'movieCd' and (value in movielist):
#                 cnt=1
#                 break
#             else:
#                 movielist.append(value)
            
#             dicts.update([[keys,value]])
#         if cnt==1:
#             continue

#         writer.writerow(dicts)
#         del dicts


#   ans= [
#    {
#         "movieCd": "blabla",
#         "movieNm": "asdasfa",
#         "audiAcc": 3458
#     }
#       ]
