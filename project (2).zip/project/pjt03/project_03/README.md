# pjt03 - HTML/CSS를 활용한 웹 사이트 구성

- HTML과 CSS를 연결해 홈페이지를 원하는 대로 조작.
- position, float, line-height,text-align 속성을 활용한 정렬. 
- background 속성을 활용한 그림 삽입

