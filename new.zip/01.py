T=int(input())

for i in range(T):
    NM=input().split()
    N=int(NM[0])
    M=int(NM[1])
    sheet=[[0 for x in range(N)] for y in range(N)]
    square=[[int(x) for x in input().split()] for y in range(M)]
    ans=0
    for k in range(len(square)):
        for j in range(square[k][0]-1,square[k][2]): #3 j: 1 2 3
            for u in range(square[k][1]-1,square[k][3],1): # u: 2 3 4 5
                sheet[j][u]=1
    for y in range(len(sheet)):
        for x in range(len(sheet)):
            if sheet[y][x]==1:
                ans+=1
    print('#{} {}'.format(i+1,ans))