T=int(input())



for i in range(T):
    NMK=[int(x) for x in input().split()]
    N=NMK[0] #행
    M=NMK[1] #열
    K=NMK[2]
    sheet=[[int(x) for x in input().split()] for y in range(N)]
    maxi = 0
    for j in range(N-K+1):
        for k in range(M-K+1):
            square = 0
            white = 0
            for u in range(K):
                for m in range(K):
                    square+=sheet[u+j][m+k] # [K-2],[K-2]
            for q in range(K-2):
                for w in range(K-2):
                    white+=sheet[q+j+1][w+k+1]
            if square-white>maxi:
                maxi=square-white
    print('#{} {}'.format(i+1,maxi))





