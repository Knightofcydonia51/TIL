

T=int(input())


def dfs(x, y):
    global a
    visited[y][x]=a

    dx=[-1,1,0,0,-1,1,-1,1] #좌우상하
    dy=[0,0,-1,1,-1,-1,1,1]
    for j in range(8):
        nx=x+dx[j]
        ny=y+dy[j]
        if 0< nx <N and 0< ny <N:
            if geo[ny][nx]>0 and visited[ny][nx]==0:
                dfs(nx,ny)

for i in range(T):
    N=int(input())
    geo=[[int(x) for x in input().split()]for y in range(N)]
    visited=[[0 for x in range(N)] for y in range(N)]

    a=1
    cnt=0
    for y in range(len(geo)):
        for x in range(len(geo)):
            if geo[y][x]>0 and visited[y][x]==0:
                dfs(x,y)
                a+=1
                cnt+=1
    for i in range(len(visited)):
        print(visited[i])
    print('#{} {}'.format(i+1,cnt))


    # print('#{} {}'.format(i+1, ))

